﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Agenda.Models
{
    public class AgendaModel
    {
        public int ID { get; set; }
        public DateTime EventDate { get; set; }
        public string Title { get; set; }
        public string Comment { get; set; }
    }
}
