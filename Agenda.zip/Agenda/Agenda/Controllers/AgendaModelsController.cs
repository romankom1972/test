﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Agenda.Models;

namespace Agenda.Controllers
{
    public class AgendaModelsController : Controller
    {
        private readonly AgendaContext _context;

        public AgendaModelsController(AgendaContext context)
        {
            _context = context;
        }

        // GET: AgendaModels
        public async Task<IActionResult> Index()
        {
            return View(await _context.AgendaModel.ToListAsync());
        }

        // GET: AgendaModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var agendaModel = await _context.AgendaModel
                .SingleOrDefaultAsync(m => m.ID == id);
            if (agendaModel == null)
            {
                return NotFound();
            }

            return View(agendaModel);
        }

        // GET: AgendaModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AgendaModels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,EventDate,Title,Comment")] AgendaModel agendaModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(agendaModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(agendaModel);
        }

        // GET: AgendaModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var agendaModel = await _context.AgendaModel.SingleOrDefaultAsync(m => m.ID == id);
            if (agendaModel == null)
            {
                return NotFound();
            }
            return View(agendaModel);
        }

        // POST: AgendaModels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,EventDate,Title,Comment")] AgendaModel agendaModel)
        {
            if (id != agendaModel.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(agendaModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AgendaModelExists(agendaModel.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(agendaModel);
        }

        // GET: AgendaModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var agendaModel = await _context.AgendaModel
                .SingleOrDefaultAsync(m => m.ID == id);
            if (agendaModel == null)
            {
                return NotFound();
            }

            return View(agendaModel);
        }

        // POST: AgendaModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var agendaModel = await _context.AgendaModel.SingleOrDefaultAsync(m => m.ID == id);
            _context.AgendaModel.Remove(agendaModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AgendaModelExists(int id)
        {
            return _context.AgendaModel.Any(e => e.ID == id);
        }
    }
}
